# LIBRARIES
import turtle

# CONSTANTS
message = "My Demo Badge"

# GLOBAL VARIABLES
screen = turtle.Screen()
myTurtle = turtle.Turtle()

# SUBPROGRAMS

# draw a filled polygon
def polygon(pTurtle, pSides, pLength, pFillColor, pEdgeColor, pX, pY):
    # setup the polygon    
    pTurtle.penup()
    pTurtle.goto(pX, pY)
    pTurtle.pendown()
    pTurtle.fillcolor(pFillColor)
    pTurtle.pencolor(pEdgeColor)
    pTurtle.begin_fill()

    # main loop to draw each side
    for count in range(pSides):
        pTurtle.forward(pLength)
        pTurtle.right(360 / pSides)

    # complete the fill
    pTurtle.end_fill()

# MAIN

# setup screen
screen.bgcolor("grey")
myTurtle.speed(0)

# main loop to draw polgons
for count in [-140, -70, 0, 70, 140]:
    polygon(myTurtle, 6, 35, "teal", "black", count, 0)


# write a label for the badge
myTurtle.penup()
myTurtle.goto(-150, -140)
myTurtle.color("navy")
# Note: .write is not one of the turtle methods that appears on the PLS so just for fun!
myTurtle.write(message, align="center", font=("Arial", 18, "bold"))

# hide the turtle and leave screen visible
myTurtle.hideturtle()
turtle.done()
