# LIBRARIES

import turtle

# CONSTANTS


# GLOBAL VARIABLES


# SUBPROGRAMS


# MAIN PROGRAM



# Keep the window open until the user closes it
turtle.done()