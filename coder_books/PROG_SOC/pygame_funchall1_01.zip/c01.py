import random
import pygame

pygame.init()

WIDTH, HEIGHT = 700, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Catch the Coins")

clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)
big_font = pygame.font.SysFont(None, 56)

# ==> TASK 4: The paddle should look more like a bucket: change what is drawn to have a collection bucket!
BUCKET_WIDTH = 120
BUCKET_HEIGHT = 24
BUCKET_Y = HEIGHT - 40
BUCKET_SPEED = 420

bucket = pygame.Rect(
    WIDTH // 2 - BUCKET_WIDTH // 2,
    BUCKET_Y,
    BUCKET_WIDTH,
    BUCKET_HEIGHT,
)

coins = []
score = 0

spawn_timer = 0
# ==> TASK 3: Coins are falling too slowly. Give the user a choice of three difficulty levels (easy/medium/hard)
SPAWN_EVERY_MS = 450

# ==> TASK 2: 20 seconds is too short! Give the User a choice of 3 game options (20/40/60 seconds)
GAME_TIME = 20  # seconds

start_time = pygame.time.get_ticks()
running = True

while running:
    dt = clock.tick(60) / 1000
    now = pygame.time.get_ticks()
    time_left = max(0, GAME_TIME - (now - start_time) / 1000)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    
    # ==> TASK 1: The controls are reversed! Change the math symbols so LEFT moves left (-=) and RIGHT moves right (+=).
    if keys[pygame.K_LEFT]:
        bucket.x += BUCKET_SPEED * dt
    if keys[pygame.K_RIGHT]:
        bucket.x -= BUCKET_SPEED * dt

    if bucket.left < 0:
        bucket.left = 0
    if bucket.right > WIDTH:
        bucket.right = WIDTH

    if time_left > 0:
        spawn_timer += dt * 1000
        if spawn_timer >= SPAWN_EVERY_MS:
            spawn_timer = 0
            coins.append({
                "x": random.randint(20, WIDTH - 20),
                "y": -20,
                "speed": random.randint(180, 300),
                "radius": 12,
            })

        remaining = []
        for coin in coins:
            coin["y"] += coin["speed"] * dt

            coin_rect = pygame.Rect(
                coin["x"] - coin["radius"],
                coin["y"] - coin["radius"],
                coin["radius"] * 2,
                coin["radius"] * 2,
            )

            if bucket.colliderect(coin_rect):
                score += 1
            elif coin["y"] - coin["radius"] < HEIGHT:
                remaining.append(coin)

        coins = remaining

    screen.fill((20, 30, 60))

    for coin in coins:
        pygame.draw.circle(
            screen,
            (255, 215, 0),
            (int(coin["x"]), int(coin["y"])),
            coin["radius"],
        )
        pygame.draw.circle(
            screen,
            (200, 160, 0),
            (int(coin["x"]), int(coin["y"])),
            coin["radius"],
            2,
        )

    pygame.draw.rect(screen, (160, 82, 45), bucket, border_radius=8)
    pygame.draw.rect(screen, (220, 160, 90), bucket, 3, border_radius=8)

    score_text = font.render(f"Score: {score}", True, (255, 255, 255))
    time_text = font.render(f"Time: {time_left:0.1f}", True, (255, 255, 255))

    screen.blit(score_text, (20, 20))
    screen.blit(time_text, (WIDTH - 150, 20))

    if time_left <= 0:
        end_text = big_font.render("Time's up!", True, (255, 255, 255))
        final_text = font.render(f"Final score: {score}", True, (255, 255, 255))
        tip_text = font.render("Close the window to finish", True, (220, 220, 220))

        screen.blit(end_text, (WIDTH // 2 - end_text.get_width() // 2, 180))
        screen.blit(final_text, (WIDTH // 2 - final_text.get_width() // 2, 245))
        screen.blit(tip_text, (WIDTH // 2 - tip_text.get_width() // 2, 290))

    pygame.display.flip()

pygame.quit()